
                                            # логіка оптимізація кількості

import pandas as pd
import numpy as np
from pandas import DataFrame
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.formula.api import ols
import plotly.express as px
import plotly.graph_objects as go


def fun_optimize(var_opt, var_range, var_cost, df):
    """[summary]

    Args:
        var_opt ([string]): []
        var_range ([int]): [Значенням буде ціна або кількість на основі вибору, зробленого в інтерфейсі користувача]
        var_cost ([type]): [Це фіксована вартість, введена з інтерфейсу користувача]
        df ([type]): [Набір даних для нашого випадку використання]

    Returns:
        [list]: [Повертає кадр даних для таблиці,
                 діаграма ціни та кількості,
                 діаграма для оптимізованого набору кількості для максимального доходу,
                 Оптимізоване значення доходу]
    """

    fig_PriceVsQuantity = px.scatter(
        df, x="Price", y="Quantity", color="Year", trendline="ols")

    # Побудова базової моделі: у нашому випадку ми створимо дуже просту модель OLS (звичайний найменший квадрат).
    model = ols("Price ~ Quantity ", data=df).fit()

    Quantity = list(range(var_range[0], var_range[1], 10))
    cost = int(var_cost)
    Price = []
    Revenue = []
    for i in Quantity:
        demand = model.params[0] + (model.params[1] * i)
        Price.append(demand)
        Revenue.append((i) * (demand - cost))

    # створити структуру даних ціни та доходу
    profit = pd.DataFrame(
        {"Price": Price, "Quantity": Quantity, "Revenue": Revenue})

    max_val = profit.loc[(profit['Revenue'] == profit['Revenue'].max())]
    

    fig_QuantityVsRevenue = go.Figure()
    fig_QuantityVsRevenue.add_trace(go.Scatter(
        x=profit['Quantity'], y=profit['Revenue']))
    fig_QuantityVsRevenue.add_annotation(x=int(max_val['Quantity']), y=int(max_val['Revenue']),
                                         text="Maximum Revenue",
                                         showarrow=True,
                                         arrowhead=1)

    fig_QuantityVsRevenue.update_layout(
        showlegend=False,
        xaxis_title="Quantity",
        yaxis_title="Revenue")

    fig_QuantityVsRevenue.add_vline(x=int(max_val['Quantity']), line_width=2, line_dash="dash",
                                    line_color="red", opacity=0.25)

    return [profit, fig_QuantityVsRevenue, fig_PriceVsQuantity, round(max_val['Quantity'].values[0],2), round(max_val['Revenue'].values[0],3)]
